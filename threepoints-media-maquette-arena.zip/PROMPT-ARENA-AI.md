# PROMPT ARENA AI — THREEPOINTS MEDIA

Utilise les fichiers du dossier `site/` comme base fonctionnelle, les images dans `site/assets/` et les deux maquettes visuelles dans `references/`. Conserve l’identité du logo dans `references/logo-reference-capture.png` : trois points noir, rouge, noir et typographie threepoints Media. Palette #111110, #E30613, #FFFFFF, #929092.

Construis un site français premium, responsive et immersif pour Threepoints Media, agence de communication au Maroc. Sections : accueil cinématique, 6 services (création web, visites virtuelles 360°, production audiovisuelle, marketing digital, branding, SEO), démonstration 360°, portfolio, à propos, contact. Reproduis au plus près le langage visuel de `references/maquette-3d-complete.png` : fond noir, villa architecturale, typographie géante, cartes en relief, accents rouges, transitions GSAP/Three.js.

IMPORTANT : les images fournies sont des DÉCOUPES DE MAQUETTE conceptuelle, pas des photos authentiques de réalisations. Elles servent de placeholders graphiques. Remplace-les ultérieurement par des photos originales autorisées. N’invente ni clients ni chiffres de résultats ni coordonnées. Les visites 360° nécessitent de vraies images panoramiques équirectangulaires : intégrer Marzipano ou Pannellum avec une démonstration clairement identifiée, sans faire passer une image ordinaire pour une visite 360°.

Prépare une exportation statique Hostinger : index.html à la racine de public_html, chemins relatifs, aucun backend obligatoire pour le rendu. Formulaire de contact avec solution fonctionnelle à configurer et contrôles anti-spam. Optimisation mobile, SEO, accessibilité et prefers-reduced-motion.
